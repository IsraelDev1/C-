﻿using ExerIndividualOrCompany.Entities;
using System;
using System.Collections.Generic;
using System.Globalization;

namespace ExerIndividualOrCompany
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Person> list = new List<Person>();

            Console.Write("Enter the number of tax payers: ");
            int n = int.Parse(Console.ReadLine());

            for (int i = 1; i <= n; i++)
            {
                Console.WriteLine($"Tax payer #{i} data: ");
                Console.Write("Individual or Legal/Company (i/ c): ");
                char ch = char.Parse(Console.ReadLine().ToLower());
                if (ch == 'i')
                {
                    Console.Write("Name: ");
                    string name = Console.ReadLine();
                    Console.Write("Annual income: ");
                    double annualIncome = double.Parse(Console.ReadLine(), CultureInfo.InvariantCulture);
                    Console.Write("Health Expenditures: ");
                    double expenditure = double.Parse(Console.ReadLine(), CultureInfo.InvariantCulture);

                    list.Add(new IndividualPerson(name, annualIncome, expenditure));
                }else if (ch == 'c')
                {
                    Console.Write("Name: ");
                    string name = Console.ReadLine();
                    Console.Write("Annual income: ");
                    double annualIncome = double.Parse(Console.ReadLine(), CultureInfo.InvariantCulture);
                    Console.Write("Number of employees: ");
                    int employees = int.Parse(Console.ReadLine());

                    list.Add(new LegalPerson(name, annualIncome, employees));
                }
            }

            Console.WriteLine();
            Console.WriteLine("Taxes paid: ");

            foreach (Person p in list)
            {
                Console.WriteLine(p);
            }

            double sum = 0;
            foreach (Person person in list)
            {
                sum += person.Tax();               
            }

            Console.WriteLine();
            Console.WriteLine("Total taxes: $ " + sum.ToString("F2", CultureInfo.InvariantCulture));
        }
    }
}
