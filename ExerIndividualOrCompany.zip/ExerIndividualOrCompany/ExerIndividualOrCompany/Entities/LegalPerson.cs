﻿using System.Globalization;

namespace ExerIndividualOrCompany.Entities
{
    class LegalPerson : Person
    {
        public int NumberEmployees { get; set; }

        public LegalPerson(string name, double annualIncome, int numberEmployees) : base(name, annualIncome)
        {
            NumberEmployees = numberEmployees;
        }
        public LegalPerson(string name, double annualIncome, double taxRate, int numberEmployees) : base(name, annualIncome, taxRate)
        {
            NumberEmployees = numberEmployees;
        }

        public override double Tax()
        {
            if (NumberEmployees < 10)
            {
                TaxRate = 0.16;
                return AnnualIncome * TaxRate;
            }
            else
            {
                TaxRate = 0.14;
                return AnnualIncome * TaxRate;
            }
        }
        public override string ToString()
        {
            return Name
                + ", $ "
                + Tax().ToString("F2", CultureInfo.InvariantCulture);
        }
    }
}
