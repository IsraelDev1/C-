﻿using System.Globalization;

namespace ExerIndividualOrCompany.Entities
{
    class IndividualPerson : Person
    {
        public double HealthSpending { get; set; }

        public IndividualPerson(string name, double annualIncome, double healthSpending) : base(name, annualIncome)
        {
            HealthSpending = healthSpending;
        }

        public IndividualPerson(double healthSpending, string name, double annualIncome, double taxRate) : base(name, annualIncome, taxRate)
        {
            HealthSpending = healthSpending;
        }

        public override double Tax()
        {
            if (AnnualIncome < 20000)
            {
                TaxRate = 0.15;
                if (HealthSpending > 0)
                {
                    HealthSpending = HealthSpending / 2;
                }
                return (AnnualIncome * TaxRate) - HealthSpending;
            }
            else
            {
                TaxRate = 0.25;
                if (HealthSpending > 0)
                {
                    HealthSpending = HealthSpending / 2;
                }
                return (AnnualIncome * TaxRate) - HealthSpending;
            }
        }

        public override string ToString()
        {
            return Name
                + ", $ "
                + Tax().ToString("F2", CultureInfo.InvariantCulture);
        }
    }
}
