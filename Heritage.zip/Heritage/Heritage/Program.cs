﻿using Heritage.Entities;
using System;
using System.Collections.Generic;
using System.Globalization;

namespace Heritage
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Product> productList = new List<Product>();

            Console.Write("Enter the number of products: ");
            int n = int.Parse(Console.ReadLine());
            Console.WriteLine();

            for (int i = 1; i <= n; i++)
            {
                Console.WriteLine($"Product #{i} data: ");
                Console.Write("Common, used or imported (c/u/i)? ");
                char choice = char.Parse(Console.ReadLine().ToLower());
                if (choice == 'i')
                {
                    Console.Write("Name: ");
                    string name = Console.ReadLine();
                    Console.Write("Price: ");
                    double price = double.Parse(Console.ReadLine(), CultureInfo.InvariantCulture);
                    Console.Write("Customs Fee: ");
                    double fee = double.Parse(Console.ReadLine(), CultureInfo.InvariantCulture);

                    productList.Add(new ImportedProduct(name, price, fee));
                }else if (choice == 'u')
                {
                    Console.Write("Name: ");
                    string name = Console.ReadLine();
                    Console.Write("Price: ");
                    double price = double.Parse(Console.ReadLine(), CultureInfo.InvariantCulture);
                    Console.Write("Manufacture Date(DD/MM/YYYY): ");
                    DateTime manufac = DateTime.Parse(Console.ReadLine());

                    productList.Add(new UsedProduct(name, price, manufac));
                }
                else
                {
                    Console.Write("Name: ");
                    string name = Console.ReadLine();
                    Console.Write("Price: ");
                    double price = double.Parse(Console.ReadLine(), CultureInfo.InvariantCulture);

                    productList.Add(new Product(name, price));
                }
            }

            Console.WriteLine("PRICE TAGS: ");
            Console.WriteLine();

            foreach (Product product in productList)
            {
                Console.WriteLine(product.PriceTag());
            }

        }
    }
}
