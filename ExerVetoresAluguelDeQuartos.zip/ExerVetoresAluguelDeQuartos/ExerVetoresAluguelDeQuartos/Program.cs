﻿using System;

namespace ExerVetoresAluguelDeQuartos {
    class Program {
        static void Main(string[] args) {

            Estudante[] vetQuartos = new Estudante[10];

            Console.Write("De quantos quartos precisam? ");
            int nEstudantes = int.Parse(Console.ReadLine());

            for (int i = 1; i <= nEstudantes; i++) {
                Console.WriteLine("ALUGUEL #" + i);
                Console.Write("NOME: ");
                string nome = Console.ReadLine();
                Console.Write("EMAIL: ");
                string email = Console.ReadLine();
                Console.Write("QUARTO ESCOLHIDO (1 À 9): ");
                int nQuarto = int.Parse(Console.ReadLine());
                Console.WriteLine("\n");

                int aux = i;
                while (nQuarto != aux) {
                    if (nQuarto < aux) {
                        aux--;
                        if (nQuarto == aux) {
                            vetQuartos[aux] = new Estudante { Nome = nome, Email = email, Quarto = nQuarto };
                        }
                    }
                    else {
                        aux++;
                        if (nQuarto == aux) {
                            vetQuartos[aux] = new Estudante { Nome = nome, Email = email, Quarto = nQuarto };
                        }
                    }
                }
            }

            Console.WriteLine("QUARTOS ALUGADOS: ");
            for (int i = 1; i <= vetQuartos.Length; i++) {
                if(vetQuartos[i] != null) { //por padrão o vetor de objetos tem posições nulas
                    Console.WriteLine(i + ": " + vetQuartos[i].Nome + ", " + vetQuartos[i].Email);
                }
                   
            }

        }
    }
}
