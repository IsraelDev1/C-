﻿using System;
using System.Globalization;

namespace ProjetoContaBanco {
    class Program {
        static void Main(string[] args) {

            Console.Write("Número da conta: ");
            int numeroConta = int.Parse(Console.ReadLine());
            Console.Write("Titular da conta: ");
            string titular = Console.ReadLine();
            Console.Write("Fará um depósito inicial (s/n)? ");
            char opcaoDeposito = char.Parse(Console.ReadLine());
            double deposito = 0;
            if (opcaoDeposito == 's') {
                Console.Write("Valor do depósito inicial: ");
                deposito = double.Parse(Console.ReadLine(), CultureInfo.InvariantCulture);
            }

            Conta c1 = new Conta(numeroConta, titular, deposito);

            Console.WriteLine("\nDados da conta atualizados: \n" + c1 + "\n");

            Console.Write("Valor para depósito: ");
            double novoDeposito = double.Parse(Console.ReadLine(), CultureInfo.InvariantCulture);
            c1.Depositar(novoDeposito);
            Console.WriteLine("\nDados da conta atualizados: \n" + c1);

            Console.Write("\nValor para saque: ");
            double novoSaque = double.Parse(Console.ReadLine(), CultureInfo.InvariantCulture);
            c1.Sacar(novoSaque);
            Console.WriteLine("\nDados da conta atualizados: \n" + c1);

        }
    }
}
