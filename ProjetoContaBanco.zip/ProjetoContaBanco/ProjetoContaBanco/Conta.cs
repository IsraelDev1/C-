﻿using System.Globalization;

namespace ProjetoContaBanco {
    class Conta {

        public string NomeConta { get; set; }
        public int NumeroConta { get;  private set; }
        public double Saldo { get;  private set; }

        public Conta(int numero, string nome, double deposito) {
            NumeroConta = numero;
            NomeConta = nome;
            Depositar(deposito);
        }

        public void Depositar(double novoDeposito) {
            Saldo = Saldo + novoDeposito;
        }

        public void Sacar(double novoSaque) {
            Saldo = Saldo - novoSaque - 5;
        }

        public override string ToString() {
            return "Conta " +
                NumeroConta +
                ", Titular: " +
                NomeConta +
                ", Saldo: $ " +
                Saldo.ToString("F2", CultureInfo.InvariantCulture);
        }

    }
}
