﻿namespace tabuleiro {
    enum Cor {

        Branca,
        Preta,
        Amarela,
        Azul,
        Vermelha,
        Verde,
        Laranja
    }
}
